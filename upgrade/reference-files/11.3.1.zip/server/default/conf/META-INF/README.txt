============================================================================
           Migration from hivemodule.xml to service-points.conf
============================================================================

Direct editing of the hivemodule.xml file is no longer supported. Instead,
please use the service-points.conf file in server/default/conf to configure
service implementation classes.